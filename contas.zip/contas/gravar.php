<?php
//Conectar banco de dados
include 'conexao.php';
$usuario = $_POST ["txt_usuario"];
$email = $_POST ["txt_email"];
$senha = $_POST ["txt_senha"];
$csenha = $_POST["txt_csenha"];

$sql = mysql_query("select * from tb_login
                    where usuario='$usuario'
                    or email='$email'");
// Verificar se usuario ou email ja existem na tabela;
if(mysql_num_rows($sql) > 0){
    echo "<center>";
    echo "<hr>";
    echo "Conta ja cadastrada";
    echo "<hr>";
}
else{
    $sql = mysql_query("insert into tb_login (usuario,email,senha) values ('$usuario','$email','$senha')");
}

if ($senha !== $csenha){
    echo "Senhas não conferem!";
    return;

}

if (empty ($usuario) ||
    empty ($email) ||
    empty ($senha) ||
    empty ($csenha)) {
        echo "Preencha todos os campos!";
        return;
        
    }

    ?>