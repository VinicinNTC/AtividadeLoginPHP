<?php
//Conectar banco de dados
include 'conexao.php';
$usuario = $_GET ["txt_usuario"];
$email = $_GET ["txt_email"];
$senha = $_GET ["txt_senha"];

$sql = mysql_query("select * from tb_login
                    where usuario='$usuario'
                    or email='$email'");
// Verificar se usuario ou email ja existem na tabela;
if(mysql_num_rows($sql) <= 0){
    echo "<center>";
    echo "<hr>";
    echo "Conta não cadastrada";
    echo "<hr>";
}
else{
    $sql = mysql_query("");
}
?>